<?php

	include('_nib_config.php');

    $currPath = $_POST['currPath'];

    if (!empty($_POST['password']))
    {
		if ($_POST['password'] == $password)
		{
			setcookie('nibpass', md5($_POST['password']), time()+(3600*60));
		}
	}

	if (!empty($_POST['newPath']))
    {
        $newPath = str_replace('.', '', $_POST['newPath']);
        $newPath = str_replace('/', '', $newPath);
        $newPath = str_replace('\\', '', $newPath);

        mkdir($currPath . '/' . $newPath);

        $newPath = $currPath . '/' . $newPath;
    }
    else
        $newPath = $currPath;

    if (!empty($_FILES['newPic']['name']))
    {
        $newName = $_FILES['newPic']['name'];
        if (in_array(substr($newName, strpos($newName, '.')+1), $imageTypes) && (strpos($_FILES['newPic']['type'], 'image') !== false))
            move_uploaded_file($_FILES['newPic']['tmp_name'], $newPath . '/' . $newName);
    }

    header('Location: index.php?'.$newPath);

?>