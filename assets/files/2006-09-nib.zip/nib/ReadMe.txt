===============================================================================
Nice Image Browser
by Kenneth "Shrimp" Watson                                       September 2006
http://shrimpworks.za.net/
===============================================================================


1. ABOUT
-------------------------------------------------------------------------------
The Nice Image Browser is a small, light-weight, PHP-powered image gallery. It
does not rely on any databases, external modules or services, or special web
server configurations.

A few features include:

 o The gallery is normal folder on your web server/site, full of PNG, JPEG, and
   GIF images.
 o Sub-folders automatically become sub-galleries, allowing you to sort your
   images into logical browsing paths.
 o You can easily create new sub-galleries and upload new images at any level
   in your gallery.
 o Automatic, dynamic thumbnail generation, with customisable thumbnail sizes.
 o Automatic down-scaling of large images if they are too large to fit in the
   browser window.
 o Easy setup, just drop the files into any directory on your website for an
   instant gallery!


2. INSTALL
-------------------------------------------------------------------------------
A note on requirements - you need at least PHP5, with the GD image module
loaded. Almost all web hosts have GD enabled by default, and if you're running
your own server, well it's up to you to ensure it's enabled.

Installation is really simple - all you need to do is place the gallery files
somewhere on your web server/site. The location you choose to install the
gallery will also be where your actual image files will be located.

Once you've dropped the files onto your site, you can customise the
"_nib_config.php" file. The only option you should really need to set is
$password, which will be used to prevent just anyone being able to upload new
images to your gallery.

Finally, you should make sure the gallery directory is writable by your web
server user. This is normally "www-data" on many Linux setups, or
"IUSR_<serverName>" on Windows machines running IIS.


3. USAGE
-------------------------------------------------------------------------------
To open your gallery, just browse to the URL of the gallery directory
(eg. http://yoursite.za.net/gallery/). To browse the gallery content, you need
simply click folders and images to navigate around.

To add an image to the gallery, you'll first need to log in. Enter the password
you defined in $password in "_nib_config.php" in the top-left "Password:" entry
box, and click "Go".

Once logged in, the password entry will be replaced by a file upload prompt. 
Browse for the image file you want to upload, and click "Go" to store the file
in the gallery. Uploaded images will be stored within the sub-gallery you are
currently viewing.

You can also create new sub-galleries using the "Create new sub-gallery" entry
box. If you want to create a new empty sub-gallery, you may leave the upload
image entry empty. If you create a new sub-gallery, and upload an image at the
same time, the image will be automatically placed within the sub-gallery.

