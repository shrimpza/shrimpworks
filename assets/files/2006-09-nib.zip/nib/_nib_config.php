<?php

    // list of valid file/image types to list
	$imageTypes = array('jpeg', 'jpg', 'png', 'gif');

	// password you have to enter before you can upload images
	$password = "hello";

    // set the desired thumbnail width and height, in pixels
    $thumb_width = 200;
    $thumb_height = 160;

?>