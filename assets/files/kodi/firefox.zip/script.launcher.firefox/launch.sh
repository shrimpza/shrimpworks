#!/bin/bash

DISPLAY=:0 /usr/bin/firefox
