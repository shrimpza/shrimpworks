<?php
    // "myTube" YouTube downloader and mpeg converter
    // by Kenneth "Shrimp" Watson -- http://shrimpworks.za.net/
    // October 2006
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>myTube</title>
  <link rel="stylesheet" href="media/style.css" type="text/css" />
  <script>
    function fetchRecent(slug)
    {
      document.getElementById('ajaxrofl').src = 'mytube.php?fetch=' + slug;
    }
  </script>
</head>

<body>

<iframe name="ajaxrofl" id="ajaxrofl" style="display: none;" onload="document.getElementById('loading').style.display='none';"></iframe>

<div id="main">
  <div class="title">myTube</div>

  <form action="mytube.php" target="ajaxrofl" method="get" id="getform" onsubmit="document.getElementById('loading').style.display='';">
    YouTube Video URL:<br />
    <input type="text" name="url" id="url" value="http://" onfocus="if(this.value=='http://')this.value='';" />
    <button onclick="document.getElementById('loading').style.display=''; document.getElementById('getform').submit();">Download</button>
  </form>

  <div id="loading">
    <img src="media/loading.gif" width="100%" height="19"/>
  </div>

  <div id="recent">
    <div class="title">Recently downloaded:</div>
    <div class="list">
      <?php
        // display the list of files downloaded for great justice. erm, for easy access.
        $recentDownloads = file(dirname(__FILE__) . '/archive/index');
        $recentDownloads = array_reverse($recentDownloads);
        foreach ($recentDownloads as $recent)
        {
            $recent = explode("\t", $recent);
            echo date('Y M d H:i', trim($recent[2])) .': <a href="#" onclick="fetchRecent(\''.trim($recent[0]).'\')">' . trim($recent[1]) . "</a><br />\n";
        }
      ?>
    </div>
  </div>
</div>

<div align="right" class="pimp"><small>myTube - <img src="media/shrimpworks.png" border="0" align="absmiddle"/> <a href="http://shrimpworks.za.net/">by ShrimpWorks</a></small></div>

</body>
 
</html>