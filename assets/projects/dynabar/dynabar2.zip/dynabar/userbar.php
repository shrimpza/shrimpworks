<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

    class Dynabar
    {
        var $bar;
        var $image;
        var $expires;

        function Dynabar($id)
        {
            $this->bar = fetchUserBar($id);

            if ($this->bar['use_cache'])
            {
                $this->expires = "Expires: " . date("D, d M Y H:i:s T", strtotime('+' . $this->bar['cache_time'] . ' seconds', filemtime('cache/'.$this->bar['id'].'.png')));
                return;
            }

            if (!file_exists('images/content/'.$this->bar['base']))
            {
                $this->bar['base'] = 'default.png';
                $this->bar['format'] = 'png';
            }

            if (!(bool)$this->bar['grad'])
            {
                switch ($this->bar['format'])
                {
                    case 'png': 
                        $this->image = imagecreatefrompng('images/content/'.$this->bar['base']);
                        break;
                    case 'jpg': 
                        $this->image = imagecreatefromjpeg('images/content/'.$this->bar['base']);
                        break;
                    case 'jpeg': 
                        $this->image = imagecreatefromjpeg('images/content/'.$this->bar['base']);
                        break;
                    case 'gif': 
                        $this->image = imagecreatefromgif('images/content/'.$this->bar['base']);
                        break;
                }
            }
            else
            {
                $this->image = imagecreatetruecolor(350, 19);
                if ((bool)$this->bar['gradVert'])
                    gradUp(@$this->image, 19, 350, 0, 19, 350, substr($this->bar['gradEnd'], -6), substr($this->bar['gradStart'], -6));
                else
                    gradLeft(@$this->image, 19, 350, 0, 19, 350, substr($this->bar['gradEnd'], -6), substr($this->bar['gradStart'], -6));
            }

            $layers = array();
            if ((bool)$this->bar['scanlines'])
                $layers[] = 'images/'.$this->bar['scanlines'];
            if ((bool)$this->bar['overlay'])
                $layers[] = 'images/content/'.$this->bar['overlay'];
            if ((bool)$this->bar['shine'])
                $layers[] = 'images/shine-strong.png';
            $layers[] = 'images/border.png';

            $font = 'font/visitor-tt2-brk.ttf';

            $fontSize = 12;
            $fontColor = imagecolorallocate($this->image, 255, 255, 255) * -1;
            $fontBorderColor = imagecolorallocate($this->image, 0, 0, 0) * -1;

            $text = $this->bar['text'];

            $textPosX = 350 - textWidth($text);

            imagealphablending($this->image, true);

            foreach ($layers as $layer)
            {
                if (file_exists($layer))
                {
                    $imgTmp = imagecreatefrompng($layer);
                    imagealphablending($imgTmp, true);
                    imagecopy($this->image, $imgTmp, 0, 0, 0, 0, imagesx($imgTmp), imagesy($imgTmp));
                    imagedestroy($imgTmp);
                }
            }

            imagettftext($this->image, 10, 0, $textPosX - 1, 11, $fontBorderColor, $font, $text);	// left-top
            imagettftext($this->image, 10, 0, $textPosX + 1, 13, $fontBorderColor, $font, $text);	// right-bottom
            imagettftext($this->image, 10, 0, $textPosX - 1, 13, $fontBorderColor, $font, $text);	// left-bottom
            imagettftext($this->image, 10, 0, $textPosX + 1, 11, $fontBorderColor, $font, $text);	// right-top

            imagettftext($this->image, 10, 0, $textPosX - 1, 12, $fontBorderColor, $font, $text);	// left
            imagettftext($this->image, 10, 0, $textPosX + 1, 12, $fontBorderColor, $font, $text);	// right
            imagettftext($this->image, 10, 0, $textPosX, 11, $fontBorderColor, $font, $text);	// up
            imagettftext($this->image, 10, 0, $textPosX, 13, $fontBorderColor, $font, $text);	// down

            imagettftext($this->image, 10, 0, $textPosX, 12, $fontColor, $font, $text);

            if (!file_exists('cache'))
                mkdir('cache');
            imagepng($this->image, 'cache/'.$this->bar['id'].'.png');

            $this->expires = "Expires: " . date("D, d M Y H:i:s T", strtotime('+' . $this->bar['cache_time'] . ' seconds', filemtime('cache/'.$this->bar['id'].'.png')));
        }
    }
?>