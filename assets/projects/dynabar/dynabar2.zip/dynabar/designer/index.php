<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../functions.php');
	include('utils.inc.php');

	$plugins = array();

	if ($handle = opendir('../plugins/'))
	{
		while (false !== ($file = readdir($handle)))
		{
			if ($file != "." && $file != "..")
			{
				include_once('../plugins/'.$file);
				$file = substr($file, 0, strpos($file, '.'));
				$plugin = new $file;

				$newPlugin['id'] = $file;
				$newPlugin['name'] = $plugin->friendlyName;

                if ($plugin->enabled)
    				$plugins[] = $newPlugin;
			}
		}
		closedir($handle);
	}

	usort($plugins, 'sortPlugins');

	// Clear out temp files older than 30 minutes
	if ($handle = opendir('../bars/'))
	{
		while (false !== ($file = readdir($handle)))
		{
			if ($file != "." && $file != "..")
			{
				//$intFile = (int)trim($file);
				if (is_numeric($file))
				{
					$age =  time() - filemtime('../bars/'.$file);
					if ($age/60 > 0.5)
					{
						@unlink('../bars/'.$file);
						@unlink('../images/content/'.$file);
						@unlink('../cache/'.$file.'.png');
					}
				}
			}
		}
		closedir($handle);
	}

	$smarty = new Smarty;
	$smarty->assign('plugins', $plugins);
	$smarty->display('index.tpl');

?>