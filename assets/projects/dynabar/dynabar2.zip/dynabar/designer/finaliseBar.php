<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('utils.inc.php');

	if (isset($_GET['do']))
	{
		$search = array('.', '/', '\\', '*', '&', '|', ' ');
		for ($i = 0; $i < count($search); $i++)
			$_GET['id'] = trim(str_replace($search[$i], '_', $_GET['id']));
		for ($i = 0; $i < count($search); $i++)
			$_GET['name'] = trim(str_replace($search[$i], '_', $_GET['name']));

		if ($_GET['do'] == 'delete')
		{
			@unlink('../bars/'.$_GET['id']);
			@unlink('../images/content/'.$_GET['id'].'.png');
			@unlink('../images/content/'.$_GET['id'].'_overlay.png');
			@unlink('../cache/'.$_GET['id'].'.png');
		}
		else
		{
			@unlink('../bars/'.$_GET['name']);
			@unlink('../images/content/'.$_GET['name'].'.png');
			@unlink('../images/content/'.$_GET['name'].'_overlay.png');
			@unlink('../cache/'.$_GET['name'].'.png');
			@unlink('../cache/'.$_GET['id'].'.png');

			updateParam('base', $_GET['name'].'.png', $_GET['id'], '../');
			updateParam('overlay', $_GET['name'].'_overlay.png', $_GET['id'], '../');

			@rename('../bars/'.$_GET['id'], '../bars/'.$_GET['name']);
			@rename('../images/content/'.$_GET['id'].'.png', '../images/content/'.$_GET['name'].'.png');
			@rename('../images/content/'.$_GET['id'].'_overlay.png', '../images/content/'.$_GET['name'].'_overlay.png');
		}
	}

	$path = str_replace('designer/finaliseBar.php', 'show/'.$_GET['name'].'.png', $_SERVER['PHP_SELF']);
	$image = "http://".$_SERVER['HTTP_HOST'].$path;

	$smarty = new Smarty;
	$smarty->assign('image', $image);
	$smarty->assign('id', $_GET['name']);
	$smarty->assign('do', $_GET['do']);
	$smarty->display('barDone.tpl');

?>
