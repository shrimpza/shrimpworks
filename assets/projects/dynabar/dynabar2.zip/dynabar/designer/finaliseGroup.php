<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('utils.inc.php');

	if (isset($_GET['name']))
	{
		$search = array('.', '/', '\\', '*', '&', '|', ' ');
		for ($i = 0; $i < count($search); $i++)
			$_GET['name'] = trim(str_replace($search[$i], '_', $_GET['name']));
	}

    $_GET['bars'] = ($_GET['delay']*100) . ';' . $_GET['blend'] . $_GET['bars'];
    if (!file_exists('../bars/groups'))
        mkdir('../bars/groups');
    fwrite(fopen('../bars/groups/'.$_GET['name'], 'w+'), str_replace(';', "\n", $_GET['bars']));

	$path = str_replace('designer/finaliseGroup.php', 'group/'.$_GET['name'].'.gif', $_SERVER['PHP_SELF']);
	$image = "http://".$_SERVER['HTTP_HOST'].$path;

	$smarty = new Smarty;
	$smarty->assign('image', $image);
	$smarty->assign('id', $_GET['name']);
	$smarty->display('groupDone.tpl');

?>
