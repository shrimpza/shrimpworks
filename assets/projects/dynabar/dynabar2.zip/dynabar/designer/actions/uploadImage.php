<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../utils.inc.php');

	header('Cache-Control: no-cache, must-revalidate');

    $realId = $_GET['id'];
    if (isset($_GET['uploadOverlay']))
        $_GET['id'] = $_GET['id'] . '_overlay';

    if (isset($_FILES['uploadBase']['name']))
	{
		$format = substr($_FILES['uploadBase']['name'], strrpos($_FILES['uploadBase']['name'], '.')+1);
		if (in_array($format, array('jpg', 'png', 'gif', 'jpeg')))
		{
			switch ($format)
			{
				case 'png': 
					$base = imagecreatefrompng($_FILES['uploadBase']['tmp_name']);
					break;
				case 'jpg': 
					$base = imagecreatefromjpeg($_FILES['uploadBase']['tmp_name']);
					break;
				case 'jpeg': 
					$base = imagecreatefromjpeg($_FILES['uploadBase']['tmp_name']);
					break;
				case 'gif': 
					$base = imagecreatefromgif($_FILES['uploadBase']['tmp_name']);
					break;
			}

			if ((imagesx($base) == 350) && (imagesy($base) == 19))
			{
                imagesavealpha($base, true);
				imagepng($base, '../../images/content/'.$_GET['id'].'.png');
				$part = 'image';
				$path = '../images/content/'.$_GET['id'].'.png?wtf='.mt_rand(1,1337);

                if (isset($_GET['uploadOverlay']))
				    updateParam('overlay', $_GET['id'].'.png', $realId);
                else
    				updateParam('base', $_GET['id'].'.png', $realId);
			}
			else
			{
				$part = 'form';
				$message = 'Image is not the correct size!';
			}
		}
		else
		{
			$part = 'form';
			$message = 'Uploaded file is not an image!';
		}
	}
	else
	{
		$part = 'form';
		$message = '';
	}

	$smarty = new Smarty;
    if (isset($_GET['uploadOverlay']))
    {
    	$smarty->assign('form', 'overlaySelect');
        if ($part == 'form')
            $part = 'formOverlay';
    }
    else
    {
    	$smarty->assign('form', 'baseSelect');
    }

	$smarty->assign('part', $part);
	$smarty->assign('path', $path);
	$smarty->assign('message', $message.'<br />');
	$smarty->display('uploadImage.tpl');

?>