<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../utils.inc.php');

	header('Cache-Control: no-cache, must-revalidate');

    if (isset($_GET['name']))
	{
		$name = $_GET['name'];
		$search = array('.', '/', '\\', '*', '&', '|', ' ');
		for ($i = 0; $i < count($search); $i++)
			$name = str_replace($search[$i], '_', $name);
		
		if (is_numeric($_GET['name']))
		{
			$part = 'form';
			$message = 'You can\'t use a numeric only name.';
		}
		else if (file_exists('../../bars/'.trim($name)))
		{
			$part = 'form';
			$message = 'The name you have chosen is already in use, please choose another';
		}
		else
		{
			$part = 'name';
			updateParam('name', $_GET['name'], $_GET['id']);
		}
	}
	else
		$part = 'form';

	$smarty = new Smarty;
	$smarty->assign('part', $part);
	$smarty->assign('message', $message.'<br />');
	$smarty->assign('name', $name);
	$smarty->display('setName.tpl');

?>