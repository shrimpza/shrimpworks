<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../utils.inc.php');

	header('Cache-Control: no-cache, must-revalidate');

    if (isset($_GET['params']))
	{
		if ($_GET['params']{0} == '|')
			$_GET['params'] = substr($_GET['params'], 1);
		updateParam('params', $_GET['params'], $_GET['id']);
		echo "<script>parent.frameLoaded();</script>" . $_GET['params'];
	}
?>