<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../utils.inc.php');

	header('Cache-Control: no-cache, must-revalidate');

    if (isset($_GET['option']))
	{
		updateParam($_GET['option'], $_GET['value'], $_GET['id']);
		echo "<script>parent.frameLoaded();</script>" . $_GET['value'];
	}
?>