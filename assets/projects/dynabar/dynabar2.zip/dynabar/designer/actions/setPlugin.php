<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');
	include('../../functions.php');
	include('../utils.inc.php');

	header('Cache-Control: no-cache, must-revalidate');

    if (isset($_GET['plugin']))
	{
		include_once('../../plugins/'.$_GET['plugin'].'.php');
		$plugin = new $_GET['plugin'];
        $plugin->paramMapExtra();

		$inputs = array();

		foreach ($plugin->paramMap as $key => $value)
		{
			if (is_array($value[1]))
			{
				$options = '';
				foreach ($value[1] as $opt => $label)
					$options .= "\n<option value=\"".$opt."\">".$label."</option>";
				$option = '<select name="'.$key.'">'.$options.'</select>';
			}
			else if ($value[1] == 'str')
				$option = '<input type="text" name="'.$key.'"/>';
			else if ($value[1] == 'lbl')
                $option = '';

			$inputs[] = '<label for="'.$key.'">' . $value[0] . ': </label>' . $option . '<br />';

			updateParam('plugin', $_GET['plugin'], $_GET['id']);
		}

		$part = 'form';
	}
	else
		$part = 'form';

	$smarty = new Smarty;
	$smarty->assign('help', $plugin->help);
	$smarty->assign('inputs', $inputs);
	$smarty->assign('part', $part);
	$smarty->display('setPlugin.tpl');

?>