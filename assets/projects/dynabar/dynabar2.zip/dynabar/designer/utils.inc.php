<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	function sortPlugins($a, $b)
	{
		return ($a['name'] < $b['name']) ? -1 : 1;
	}

	function updateParam($name, $value, $file, $path = '../../')
	{
		$search = array('.', '/', '\\', '*', '&', '|', ' ');
		for ($i = 0; $i < count($search); $i++)
			$file = str_replace($search[$i], '_', $file);

        $name = trim($name);
        $value = trim($value);

		if ($value == 'true')
			$value = 1;
		else if ($value == 'false')
			$value = 0;

		if (!file_exists($path.'bars/'.$file))
			fwrite(fopen($path.'bars/'.$file, 'w'), $name.'='.$value);
		else
		{
			$bar = file($path.'bars/'.$file);
			for ($i = 0; $i < count($bar); $i++)
			{
				if (trim(substr($bar[$i], 0, strpos($bar[$i], '='))) == $name)
				{
					$bar[$i] = $name.'='.$value;
					$found = true;
				}
				$bar[$i] = trim($bar[$i]);
			}

			if (!$found)
				$bar[] = $name.'='.$value;

			fwrite(fopen($path.'bars/'.$file, 'w'), implode("\n", $bar));
		}
	}

?>