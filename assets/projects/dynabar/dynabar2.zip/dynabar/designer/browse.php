<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	include('smarty/libs/Smarty.class.php');

	$bars = array();
	if ($handle = opendir('../bars/'))
	{
		while (false !== ($file = readdir($handle)))
			if ($file != "." && $file != "..")
				if (!is_numeric($file))
					$bars[] =  $file;
		closedir($handle);
	}

	sort($bars);

	$path = "http://".$_SERVER['HTTP_HOST'].str_replace('designer/browse.php', 'show/', $_SERVER['PHP_SELF']);

	$smarty = new Smarty;
	$smarty->assign('path', $path);
	$smarty->assign('bars', $bars);
	$smarty->display('browse.tpl');
?>
