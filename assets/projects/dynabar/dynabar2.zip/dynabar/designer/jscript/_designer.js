
	var frame = document.getElementById('magicFrame');
	frame.onload = frameLoaded;

	var barName = 'unknownBar';

	setPlugin(document.getElementById('pluginList'));

	function setName(name)
	{
		barName = name;
		document.getElementById('magicFrame').src = 'actions/setName.php?id=' + someReallyRandomNumber + '&name=' + escape(name);
	}

	function uploadBaseLOL()
	{

		document.getElementById('baseUploadForm').action = 'actions/uploadImage.php?id=' + someReallyRandomNumber;
		document.getElementById('baseUploadForm').submit();
	}

	function uploadOverlayROFL()
	{

		document.getElementById('overlayUploadForm').action = 'actions/uploadImage.php?uploadOverlay=1&id=' + someReallyRandomNumber;
		document.getElementById('overlayUploadForm').submit();
	}

	function frameLoaded()
	{
		document.getElementById('previewPic').src = '../show.php?id='+someReallyRandomNumber+'&no_cache_plz='+Math.random();
	}

	function baseSelectBack()
	{
		document.getElementById('magicFrame').src = 'actions/uploadImage.php';
	}

	function overlaySelectBack()
	{
		document.getElementById('magicFrame').src = 'actions/uploadImage.php?uploadOverlay=1';
	}

	function setNameBack()
	{
		document.getElementById('magicFrame').src = 'actions/setName.php';
	}

	function setPlugin(select)
	{
		document.getElementById('magicFrame').src = 'actions/setPlugin.php?id=' + someReallyRandomNumber + '&plugin=' + escape(select.value);
	}

	function setParams()
	{
		form = document.getElementById('pluginParamForm');

		params = '';

		for (var i = 0; i < form.length; i++)
		{
			if ((form.elements[i].nodeName != "INPUT") && (form.elements[i].nodeName != "SELECT") && (form.elements[i].nodeName != "TEXTAREA"))
				continue;

			params = params + '|' + form.elements[i].name + '=' + escape(form.elements[i].value);
		}

		document.getElementById('magicFrame').src = 'actions/setParams.php?id=' + someReallyRandomNumber + '&params=' + params;
	}

	function setOption(name, option)
	{
		document.getElementById('magicFrame').src = 'actions/setOptions.php?id=' + someReallyRandomNumber + '&option=' + name + '&value=' + option.checked;
	}

	function setOptionValue(name, option)
	{
		document.getElementById('magicFrame').src = 'actions/setOptions.php?id=' + someReallyRandomNumber + '&option=' + name + '&value=' + escape(option.value);
	}

	function setScanlines(value)
	{
		document.getElementById('magicFrame').src = 'actions/setOptions.php?id=' + someReallyRandomNumber + '&option=scanlines&value=' + value;
	}

	function saveBar(action)
	{
		if (barName == 'unknownBar')
		{
			alert('Please set a name for this Dynabar!');
		}
		else
			window.location = 'finaliseBar.php?id=' + someReallyRandomNumber + '&do=' + action + '&name=' + barName;
	}