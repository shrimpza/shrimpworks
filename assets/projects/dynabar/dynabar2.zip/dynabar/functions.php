<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 120;
		var $friendlyName = "UserBar Plugin";
        var $help = "Plugin author was too lazy to include further info.";

		var $options = array();
		var $params = '';

		var $paramMap = array();

        function paramMapExtra()
        {
			// Prototype function, can be used to manage the parameter mappings at design time
        }

		function parseParams()
		{
			$params = explode('|', $this->params);
			foreach ($params as $param)
			{
				$tmp = explode('=', $param);
				$this->options[trim($tmp[0])] = trim($tmp[1]);
			}
		}

		function fetchText()
		{
			// Prototype function, should return text for userbar.
			// return false on fail.

			return false;
		}
	}

	function fetchUserBar($id)
	{
		$bar = array();

		$search = array('.', '/', '\\', '*', '&', '|', ' ');
		for ($i = 0; $i < count($search); $i++)
			$id = str_replace($search[$i], '_', $id);

		$bar['id'] = $id;

		$options = file('bars/'.$id);

		foreach ($options as $option)
		{
			$key = trim(substr($option, 0, strpos($option, '=')));
			$value = trim(substr($option, strpos($option, '=')+1));
			$bar[$key] = $value;
		}


        if (empty($bar['base']) || !isset($bar['base']))
            $bar['base'] = 'default.png';

		$bar['format'] = substr($bar['base'], strrpos($bar['base'], '.')+1);

		if (!empty($bar['plugin']))
		{
			include_once('plugins/'.$bar['plugin'].'.php');
			$plugin = new $bar['plugin'];
			if (!isset($_GET['no_cache_plz']))
				$bar['cache_time'] = $plugin->cacheTime;
		}

		if (file_exists('cache/'.$bar['id'].'.png') && (time() - @filemtime('cache/'.$bar['id'].'.png') < $bar['cache_time']))
			$bar['use_cache'] = true;
		else
		{
			if (empty($bar['plugin']))
				$bar['text'] = 'No plugin!';
			else
			{
                $plugin->params = $bar['params'];
                $plugin->parseParams();
                if ($plugin->enabled)
                {
                    $value = $plugin->fetchText();
                    if ($value !== false)
                    {
                        if (!empty($bar['prefix']))
                            $bar['prefix'] .= ' ';
                        if (!empty($bar['suffix']))
                            $bar['suffix'] = ' ' . $bar['suffix'];
                        $bar['text'] = $bar['prefix'] . $value . $bar['suffix'];
                    }
                    else
                        $bar['text'] = 'Error getting text!';
                }
                else
                {
                    $bar['text'] = 'Plugin "' . $plugin->friendlyName . '" is disabled!';
                }
			}
		}

		return $bar;
	}

	function textWidth($text)
	{
		$width = 0;

		for ($i = 0; $i < strlen($text); $i++)
		{
			switch ($text{$i})
			{
				case '<':
					$width += 4;
					break;
				case '>':
					$width += 4;
					break;
				case '(':
					$width += 3;
					break;
				case ')':
					$width += 3;
					break;
				case ',':
					$width += 3;
					break;
				case '!':
					$width += 3;
					break;
				case '.':
					$width += 3;
					break;
				case ':':
					$width += 3;
					break;
				case 'i':
					$width += 3;
					break;
				case '1':
					$width += 3;
					break;
				case ' ':
					$width += 7;
					break;
				default:
					$width += 6;
					break;
			}
		}

		return $width + 7;
	}

    function gradLeft($im, $height, $width, $step, $baseheight, $basewidth, $base, $end)
    {
        // $im is passed as @$im for the image to draw it on
        // $height is the Height of the box to draw
        // $width is the width of the box to draw
        // $step is the steps to take, a step of 10 would change the colour every 10 pixels
        // $baseheight is where to place the bottom of the rectangle
        // $basewidth is the right side of the location for the rectangle
        // $base is the start colour in hex (ffffff)
        // $end is the colour to end at in hex (000000)

        // Break colours into RGB components
        sscanf($base, "%2x%2x%2x", $rbase, $gbase, $bbase);
        sscanf($end, "%2x%2x%2x", $rend, $gend, $bend);

        // Set the Variable to step to use height
        $varstep = $width;

        // Remove potential divide by 0 errors.
        if ($rbase == $rend)
            $rend = $rend -1;
        if ($gbase == $gend)
            $gend = $gend -1;
        if ($bbase == $bend)
            $bend = $bend -1;

        // Make sure the height is at least 1 pixel
        if ($varstep == 0)
            $varstep=1;

        // Set up step modifiers for each colour
        $rmod = ($rend - $rbase) / $varstep;
        $gmod = ($gend - $gbase) / $varstep;
        $bmod = ($bend - $bbase) / $varstep;

        // Serves no real purpose.
        $white = imagecolorallocate($im, 255, 255, 255);

        // Loop for the height at a rate equal to the steps.
        for($i = 1; $i < $varstep; $i = $i + $step + 1)
        {

            //Adjust the colours
            $clour1 = ($i * $rmod) + $rbase;
            $clour2 = ($i * $gmod) + $gbase;
            $clour3 = ($i * $bmod) + $bbase;
            $col = imagecolorallocate($im, $clour1, $clour2, $clour3);

            //Paint the rectangle at current colour.
            imagefilledrectangle($im, $basewidth - $i, $baseheight - $height + 1, $basewidth - $i + $step, $baseheight, $col);
        }
    }

    function gradUp($im, $height, $width, $step, $baseheight, $basewidth, $base, $end)
    {
        // $im is passed as @$im for the image to draw it on
        // $height is the Height of the box to draw
        // $width is the width of the box to draw
        // $step is the steps to take, a step of 10 would change the colour every 10 pixels
        // $baseheight is where to place the bottom of the rectangle
        // $basewidth is the right side of the location for the rectangle
        // $base is the start colour in hex (ffffff)
        // $end is the colour to end at in hex (000000)

        // Break colours into RGB components
        sscanf($base, "%2x%2x%2x", $rbase, $gbase, $bbase);
        sscanf($end, "%2x%2x%2x", $rend, $gend, $bend);

        // Set the Variable to step to use height
        $varstep = $height;

        // Remove potential divide by 0 errors.
        if ($rbase == $rend)
            $rend = $rend -1;
        if ($gbase == $gend)
            $gend = $gend -1;
        if ($bbase == $bend)
            $bend = $bend -1;

        // Make sure the height is at least 1 pixel
        if ($varstep == 0)
            $varstep=1;

        // Set up step modifiers for each colour
        $rmod = ($rend - $rbase) / $varstep;
        $gmod = ($gend - $gbase) / $varstep;
        $bmod = ($bend - $bbase) / $varstep;

        // Serves no real purpose.
        $white = imagecolorallocate($im, 255, 255, 255);

        // Loop for the height at a rate equal to the steps.
        for($i = 1; $i < $varstep; $i = $i + $step + 1)
        {

            //Adjust the colours
            $clour1 = ($i * $rmod) + $rbase;
            $clour2 = ($i * $gmod) + $gbase;
            $clour3 = ($i * $bmod) + $bbase;
            $col = imagecolorallocate($im, $clour1, $clour2, $clour3);

            //Paint the rectangle at current colour.
            imagefilledrectangle($im, $basewidth - $width + 1, $baseheight - $i, $basewidth, $baseheight - $i + $step, $col);
        }
    }
    
    // Return the colour
    //return(@$im);

?>