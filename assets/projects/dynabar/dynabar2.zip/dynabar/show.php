<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/


    require_once('userbar.php');
	require_once('functions.php');

    if (!isset($_GET['id']))
    {
        $match = array();
        preg_match('/\/([a-zA-Z0-9_]+)\.png/', $_SERVER['PHP_SELF'], $match);
        $_GET['id'] = $match[1];
    }

    $dynabar = new Dynabar($_GET['id']);
    header('Content-Type: image/png');
    header('Content-Disposition: inline; filename='.$dynabar->bar['id'].'.png');
    header($dynabar->expires);
    fpassthru(fopen('cache/'.$dynabar->bar['id'].'.png', 'r'));

?>