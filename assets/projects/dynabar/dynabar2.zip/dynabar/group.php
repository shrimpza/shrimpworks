<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/


    require_once('userbar.php');
	require_once('functions.php');
	require_once('GifMerge.class.php');

    if (!isset($_GET['id']))
    {
        $match = array();
        preg_match('/\/([a-zA-Z0-9_]+)\.gif/', $_SERVER['PHP_SELF'], $match);
        $_GET['id'] = $match[1];
    }

	if (file_exists('cache/groups/'.$_GET['id'].'.gif') && (time() - @filemtime('cache/groups/'.$_GET['id'].'.gif') < 600))
    {
        header('Content-Type: image/gif');
        fpassthru(fopen('cache/groups/'.$_GET['id'].'.gif', 'r'));
    }
    else
    {
        $items = file('bars/groups/'.$_GET['id']);
        $delay = $items[0];
        $blend = $items[1];

        array_shift($items);
        array_shift($items);

        $bars = array();
        for ($i = 0; $i < count($items); $i++)
        {
            $bars[$i] = new Dynabar(trim($items[$i]));
            $bars[$i]->image = imagecreatefrompng('cache/'.$bars[$i]->bar['id'].'.png');
        }

        $solids = array();
        $blends = array();
        for ($i = 0; $i < count($items); $i++)
        {
            ob_start();
            imagegif($bars[$i]->image);
            $solids[$i] = ob_get_contents();
            ob_end_clean();

            if ($blend > 0)
            {
                $blends[$i] = $bars[$i]->image;
                if ($i < count($items)-1)
                    imagecopymerge($blends[$i], $bars[$i+1]->image, 0, 0, 0, 0, 350, 19, 50);
                else
                    imagecopymerge($blends[$i], $bars[0]->image, 0, 0, 0, 0, 350, 19, 50);

                ob_start();
                imagegif($blends[$i]);
                $blends[$i] = ob_get_contents();
                ob_end_clean();
            }
        }

        $frames = array('images' => array(), 'delays' => array(), 'xpos' => array(), 'ypos' => array());
        for ($i = 0; $i < count($items); $i++)
        {
            $frames['images'][] = $solids[$i];
            $frames['delays'][] = $delay;
            $frames['xpos'][] = 0;
            $frames['ypos'][] = 0;

            if ($blend > 0)
            {
                $frames['images'][] = $blends[$i];
                $frames['delays'][] = 10;
                $frames['xpos'][] = 0;
                $frames['ypos'][] = 0;
            }
        }

        $gif = new GifMerge($frames['images'], 1, 1, 1, -10, $frames['delays'], 2, $frames['xpos'], $frames['ypos'], 'C_MEMORY');

        if (!file_exists('cache/groups'))
            mkdir('cache/groups');
        fwrite(fopen('cache/groups/'.$_GET['id'].'.gif', 'w+b'), $gif->getAnimation());

        header('Content-Type: image/gif');
        echo $gif->getAnimation();
    }
?>