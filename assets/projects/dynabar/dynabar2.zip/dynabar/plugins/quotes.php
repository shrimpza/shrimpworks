<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class quotes extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 30;	// in case someone wants to see a lot?
		var $friendlyName = "Random Quotes";
        var $help = "Display a random line of text from 10 possible user-defined values.";

		var $paramMap = array(
				'quote1' => array("Quote 1", 'str'),
				'quote2' => array("Quote 2", 'str'),
				'quote3' => array("Quote 3", 'str'),
				'quote4' => array("Quote 4", 'str'),
				'quote5' => array("Quote 5", 'str'),
				'quote6' => array("Quote 6", 'str'),
				'quote7' => array("Quote 7", 'str'),
				'quote8' => array("Quote 8", 'str'),
				'quote9' => array("Quote 9", 'str'),
				'quote10' => array("Quote 10", 'str'),
			);

		function fetchText()
		{
			return $this->options['quote'.mt_rand(1,10)];
		}
	}

?>