<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class rss extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 600;
		var $friendlyName = "RSS Feed";
        var $help = "Shows the most recent headline/entry from an RSS feed (requires PHP 5)";

		var $paramMap = array(
				'url' => array('Feed URL', 'str'),
			);

		function fetchText()
		{
            if (!isset($this->options['url']))
                return "No feed!";

			$feed = simplexml_load_file($this->options['url']);
			if ($feed->channel->item)
				return $feed->channel->item[0]->title;
			else if ($feed->item)
				return $feed->item[0]->title;
			else
				return false;
		}
	}

?>