<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

    // uptime collection and formatting ripped from
    // http://www.webhostingtalk.com.au/archive/index.php/t-4259.html
    // reformatted code for better readability ;P
	class uptime extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 60;	// timeout of 1 minute
		var $friendlyName = "System uptime";
        var $help = "Display the uptime for the PC or server Dynabar is running on. Requires that Dynabar be running on a *nix system.";

		var $paramMap = array(
				'heh' => array("No options", 'lbl'),
			);

		function fetchText()
		{
            if (file_exists('/proc/uptime'))
            { 
                $f = file('/proc/uptime'); 
                $arr = explode(' ', $f[0]); 

                return 'Uptime: ' . $this->elapsedTime($arr[0]); 
            }
            else
    			return 'Missing /proc/uptime';
		}


        function elapsedTime($sec)
        {	
            if ($sec < 60)
                return $sec.' seconds';

            $days  = floor($sec	/ 86400);
            $hrs   = floor(bcmod($sec,86400)/3600);
            $mins  = round(bcmod(bcmod($sec,86400),3600)/60);

            if ($days > 0)
                $tstring = $days . ' days, '; 
            if ($hrs > 0)
                $tstring .= $hrs . ' hours, '; 
            $tstring .=	 $mins . ' minutes'; 

            return $tstring; 
		}	
    }

?>