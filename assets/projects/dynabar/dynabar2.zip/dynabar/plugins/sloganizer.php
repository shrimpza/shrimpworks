<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class sloganizer extends UbarPlugin
	{
        var $enabled = true;
		var $friendlyName = "Sloganizer";
        var $help = "Use the Sloganizer service to generate a random slogan.";

		var $paramMap = array(
				'slogan' => array('Slogan', 'str'),
			);

		function fetchText()
		{
			$slogan = @file('http://www.sloganizer.net/en/outbound.php?slogan='.$this->options['slogan']);
			if ($slogan !== false)
			{
				if (count($slogan) > 0)
					return trim(strip_tags($slogan[0]));
				else
					return "No slogan?!";
			}
			else
				return false;
		}
	}

?>