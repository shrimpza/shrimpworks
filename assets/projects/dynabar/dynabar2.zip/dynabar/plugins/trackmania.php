<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class trackmania extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 600;	// cache for 10 minutes, takes a while to generate, best not re-fetch too often
		var $friendlyName = "TrackMania";
        var $help = "Gets a TrackMania players international and national rank, as well as their score.";

		var $paramMap = array(
				'user' => array('Username', 'str'),
				'stat' => array('Show', array( -1 => 'Random',
												0 => 'National Rank',
												1 => 'International Rank',
                                )),
			);

		function fetchText()
		{
            if (!isset($this->options['user']))
                return "No username!";

            $init = @file('http://game.trackmanianations.com/online_game/getplayerinfos.php?ver=0.1.7.5&lang=en&from='.$this->options['user'].'&login='.$this->options['user']);

            if ($init !== false)
			{
                $init = explode(';', $init[0]);
                if (count($init) > 2)
                {
                    $ranks = $this->getRanks($init[3]);
                    $statStrings = array("Ranked " . $ranks[1] . " in " . $init[3] . " with " . $ranks[2] . " points",
                                         "Ranked " . $ranks[0] . " in the world with " . $ranks[2] . " points");

                    if ($this->options['stat'] < 0)
                        $this->options['stat'] = rand(0, 1);

                    return $statStrings[$this->options['stat']];

					//return trim(substr($songs[0], strpos($songs[0], ',')+1));
                }
				else
					return "No data for " . $this->options['user'];
			}
			else
				return false;
		}

        function getRanks($country)
        {
            $ranks = array(0, 0, 0);

            $int = @file('http://ladder.trackmanianations.com/ladder/getstats.php?login='.$this->options['user'].'&lang=en&ver=0.1.7.5&laddertype=g');
            if ($int !== false)
            {
                $int = explode(';', $int[0]);
                $ranks[0] = $int[5];
                $ranks[2] = $int[6];
            }

            $nat = @file('http://ladder.trackmanianations.com/ladder/getstats.php?login='.$this->options['user'].'&lang=en&ver=0.1.7.5&laddertype=g&country='.$country);
            if ($nat !== false)
            {
                $nat = explode(';', $nat[0]);
                $ranks[1] = $nat[5];
            }

            return $ranks;
        }
	}

?>