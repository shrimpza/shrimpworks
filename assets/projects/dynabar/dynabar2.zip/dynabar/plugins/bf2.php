<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class bf2 extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 600;	// cache for 10 minutes, no need to spam stats requests
		var $friendlyName = "BattleField 2 Stats";
        var $help = "Get the latest statistics for a BattleField 2 player specified by the provided Player ID.";

		var $paramMap = array(
				'stat' => array('Show', array( -1 => 'Random Stats',
												0 => 'Global Score',
												1 => 'Matches',
												2 => 'Wins',
												3 => 'Losses',
												4 => 'Kills',
												5 => 'Deaths',
												6 => 'Kill/Death Ratio',
												7 => 'Win/Loss Ratio',
					            )),
				'pid' => array('Player ID', 'str'),
			);


		var $statOptions = array(
									array('name' => 'Global Score', 'stat' => 'scor'),
									array('name' => 'Matches', 'stat' => 'mode0'),
									array('name' => 'Wins', 'stat' => 'wins'),
									array('name' => 'Losses', 'stat' => 'loss'),
									array('name' => 'Kills', 'stat' => 'kill'),
									array('name' => 'Deaths', 'stat' => 'deth'),
									array('name' => 'Kill/Death Ratio', 'stat' => 'kd'),
									array('name' => 'Win/Loss Ratio', 'stat' => 'wl'),
								);

		function fetchText()
		{
            if (!isset($this->options['pid']))
                return "No Player ID!";

			if ($this->options['stat'] < 0)
				$this->options['stat'] = rand(0, count($this->statOptions)-1);

            $stats = $this->getStats($this->options['pid']);

            return $this->statOptions[$this->options['stat']]['name'] . ': ' . $stats[$this->statOptions[$this->options['stat']]['stat']];

		}

        function getStats($pid)
        {
            ini_set("user_agent","GameSpyHTTP/1.0");

            $info = "per*,cmb*,twsc,cpcp,cacp,dfcp,kila,heal,rviv,rsup,rpar,tgte,dkas,dsab,cdsc,rank,cmsc,kick,kill,deth,suic,ospm,klpm,klpr,dtpr,bksk,wdsk,bbrs,tcdr,ban,dtpm,lbtl,osaa,vrk,tsql,tsqm,tlwf,mvks,vmks,mvn*,vmr*,fkit,fmap,fveh,fwea,wtm-,wkl-,wdt-,wac-,wkd-,vtm-,vkl-,vdt-,vkd-,vkr-,atm-,awn-,alo-,abr-,ktm-,kkl-,kdt-,kkd-";

            $data = file("http://bf2web.gamespy.com/ASP/getplayerinfo.aspx?pid=".$pid."&info=".$info);

            $stats = array_combine(explode("\t", $data[3]), explode("\t", $data[4]));

            $stats['kd'] = @round($stats['kill'] / $stats['deth'], 2);
            $stats['wl'] = @round($stats['wins'] / $stats['loss'], 2);


            return $stats;
        }
	}
?>