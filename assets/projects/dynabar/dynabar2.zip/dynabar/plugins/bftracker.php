<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class bftracker extends UbarPlugin
	{
        var $enabled = false;
		var $friendlyName = "BF2 Tracker Clan Stats";

		var $paramMap = array(
				'stat' => array('Show', array(	-1 => 'Random Stats',
													0 => 'Global Score',
													1 => 'Matches',
													2 => 'Wins',
													3 => 'Losses',
													4 => 'Kills',
													5 => 'Deaths',
													6 => 'Kill/Death Ratio',
													7 => 'Win/Loss Ratio',
					)),
				'clanid' => array('Clan ID', 'str'),
				'pid' => array('Player ID', 'str'),
			);


		var $statOptions = array(
									array('name' => 'Global Score', 'stat' => 'PLAYERGLOBALSCORE'),
									array('name' => 'Matches', 'stat' => 'PLAYERMATCHES'),
									array('name' => 'Wins', 'stat' => 'PLAYERWINS'),
									array('name' => 'Losses', 'stat' => 'PLAYERLOSS'),
									array('name' => 'Kills', 'stat' => 'PLAYERKILLS'),
									array('name' => 'Deaths', 'stat' => 'PLAYERDEATHS'),
									array('name' => 'Kill/Death Ratio', 'stat' => 'KILLSDEATHS'),
									array('name' => 'Win/Loss Ratio', 'stat' => 'WINSLOSS'),
								);

		function fetchText()
		{
			if ($this->options['stat'] < 0)
				$this->options['stat'] = rand(0, count($this->statOptions)-1);

			$bft = new bfTrackerClan($this->options['clanid']);
			$bft->parseStats();

			return $this->statOptions[$this->options['stat']]['name'] . ': ' . $bft->playerstats[$this->options['pid']][$this->statOptions[$this->options['stat']]['stat']];
		}
	}

	class bfTrackerClan
	{
		var $stack = array();

		var $claninfo = array();
		var $clanstats = array();
		var $playerstats = array();

		function bfTrackerClan($clanid)
		{
			$xml_parser = xml_parser_create();
			xml_set_element_handler($xml_parser, array(&$this, "startTag"), array(&$this, "endTag"));
			xml_set_character_data_handler($xml_parser, array(&$this, "cdata"));

			$xmllink = 'http://bf2tracker.com/livefeed/xml_clanprofile.php?clanid='.$clanid;
			$data = xml_parse($xml_parser, file_get_contents($xmllink));
			if (!$data)
				die(sprintf("XML error: %s at line %d", xml_error_string(xml_get_error_code($xml_parser)), xml_get_current_line_number($xml_parser)));

			xml_parser_free($xml_parser);
		}

		function parseStats()
		{
			// Get Clan Profile Data
			for($i = 0; $i < sizeof($this->stack[0][children][0][children]); $i++)
			{
				$valname = $this->stack[0][children][0][children][$i][name];
				$this->claninfo[$valname] = $this->stack[0][children][0][children][$i][cdata];
			}

			// Get Clan Stats Data
			for($i = 0; $i < sizeof($this->stack[0][children][1][children]); $i++)
			{
				$valname = $this->stack[0][children][1][children][$i][name];
				$this->clanstats[$valname] = $this->stack[0][children][1][children][$i][cdata];
			}

			// Get Player Data
			for($i = 0; $i < sizeof($this->stack[0][children][2][children]); $i++)
			{
				for($x = 0; $x < sizeof($this->stack[0][children][2][children][$i][children]); $x++)
				{
					$valname = $this->stack[0][children][2][children][$i][children][$x][name];
					$value = $this->stack[0][children][2][children][$i][children][$x][cdata];
					if($valname == "PLAYERID")
						$pid = $value;
					$this->playerstats[$pid][$valname] = $value;
				}
				$this->playerstats[$pid]['KILLSDEATHS'] = round($this->playerstats[$pid]['PLAYERKILLS'] / $this->playerstats[$pid]['PLAYERDEATHS'], 2);
				$this->playerstats[$pid]['WINSLOSS'] = round($this->playerstats[$pid]['PLAYERWINS'] / $this->playerstats[$pid]['PLAYERLOSS'], 2);
			}
		}


		function startTag($parser, $name, $attrs)
		{
			$tag = array("name" => $name, "attrs" => $attrs); 
			array_push($this->stack, $tag);
		}

		function cdata($parser, $cdata)
		{
			$this->stack[count($this->stack)-1]['cdata'] .= $cdata;   
		}

		function endTag($parser, $name)
		{
			$this->stack[count($this->stack)-2]['children'][] = $this->stack[count($this->stack)-1];
			array_pop($this->stack);
		}


	}
?>