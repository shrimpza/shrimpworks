<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class text extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 600;	// 10 minute timeout. no need to constantly update static text
		var $friendlyName = "Plain Text";
        var $help = "Display a plain text string.";

		var $paramMap = array(
				'text' => array("Text", 'str'),
			);

		function fetchText()
		{
			return $this->options['text'];
		}
	}

?>