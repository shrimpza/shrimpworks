<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class scrobbler extends UbarPlugin
	{
        var $enabled = true;
		var $friendlyName = "LastFM";
        var $help = "Fetches the most recently played song on from a LastFM users profile";

		var $paramMap = array(
				'user' => array('Username', 'str'),
			);

		function fetchText()
		{
            if (!isset($this->options['user']))
                return "No username!";

            $songs = @file('http://ws.audioscrobbler.com/1.0/user/'.$this->options['user'].'/recenttracks.txt');
			if ($songs !== false)
			{
				if (count($songs) > 0)
					return trim(substr($songs[0], strpos($songs[0], ',')+1));
				else
					return "Nothing playing";
			}
			else
				return false;
		}
	}

?>