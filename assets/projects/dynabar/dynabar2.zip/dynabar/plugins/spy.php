<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class spy extends UbarPlugin
	{
        var $enabled = true;
		var $cacheTime = 0;		// never cache, as it should look diferent for each viewer
		var $friendlyName = "Spy";
        var $help = "Shows random info about the user viewing the userbar.";

		var $paramMap = array(
				'text' => array("No options", 'lbl'),
			);

		function fetchText()
		{
			switch (mt_rand(0, 2))
			{
				case 0: return 'Your IP is ' . $_SERVER['REMOTE_ADDR'];
				case 1: return 'Your browser is ' . $this->userAgent();
				case 2: return 'You are using ' . $this->operatingSystem();
			}
			return $this->options['text'];
		}

		function userAgent()
		{
			if (stripos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== false)
				return 'Firefox';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false)
				return 'Internet Explorer';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== false)
				return 'Opera';
		}

		function operatingSystem()
		{
			if (stripos($_SERVER['HTTP_USER_AGENT'], 'win'))
				return 'Windows';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'mac'))
				return 'Mac OS';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'linux'))
				return 'Linux';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'OS/2'))
				return 'OS/2';
			else if (stripos($_SERVER['HTTP_USER_AGENT'], 'BeOS'))
				return 'BeOS';
		}
	}

?>