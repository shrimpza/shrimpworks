<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class qstat extends UbarPlugin
	{
        var $execPath = '/usr/bin/quakestat';   // path to qstat

        var $enabled = true;
		var $cacheTime = 120;	// 2 mins between server queries
		var $friendlyName = "QStat [exec]";
        var $help = "Shows live server stats from any game/protocol supported by QStat. Requires a *nix server with QStat installed.";

		var $paramMap = array(
				'protocol' => array("Game/protocol", array()),
                'format'  => array("Format", array(
                                                    "%n, %m, %p" => "Name, Map, Players",
                                                    "%n, %m" => "Name, Map",
                                                    "%n, %p" => "Name, Players",
                                                    "%m, %p" => "Map, Players",
                                                    "%i, %n" => "IP/Address, Name",
                                                    "%i, %m" => "IP/Address, Map",
                                                    "%i, %p" => "IP/Address, Players",
                                                    "%i, %m, %p" => "IP/Address, Map, Players",
                                                    )),
                'seperator' => array("Info Seperator", 'str'),
                'server1' => array("Server 1", 'str'),
                'server2' => array("Server 2", 'str'),
                'server3' => array("Server 3", 'str'),
                'server4' => array("Server 4", 'str'),
                'server5' => array("Server 5", 'str'),
			);

        function paramMapExtra()
        {
            $out = shell_exec($this->execPath);

            $out = str_replace("\n", "|;", $out);
            $out = str_replace("\t", " ", $out);

            preg_match_all("/;-([A-Za-z0-9\.]*) *query *(.*?)\|/", $out, $match, PREG_SET_ORDER);

        	usort($match, 'sortProtos');
            foreach ($match as $proto)
            {
                $this->paramMap['protocol'][1][trim($proto[1])] = trim($proto[2]) . ' &nbsp; [' . trim($proto[1]) . ']';
            }
        }

		function fetchText()
		{
            $tries = 20;
            $server = '';

            if (empty($this->options['seperator']))
                $this->options['seperator'] = ',';
            if (empty($this->options['format']))
                $this->options['format'] = $this->paramMap['format'][1][0];

            while (($tries > 0) && ($server == ''))
            {
                $server = trim($this->options['server'.mt_rand(1, 5)]);
                $tries --;
            }
            if ($server == '')
                return 'No server to query!';
            else
            {
                $out = explode(',', trim(shell_exec($this->execPath . ' -' . $this->options['protocol'] . ' ' . $server . ' -raw ,')));
                if ($out[2] == 'TIMEOUT')
                    return $server + ' - timeout';
                else if ($out[2] == 'ERROR')
                    return $server + ' - ' . $out[3];
                else if (count($out) < 1)
                    return 'No response from server ' . $server;
                else
                    return $this->formatText($out, $this->options['format']); //$out[2] . ', ' . $out[3] . ' ('.$out[5].'/'.$out[4].')';
            }
		}

        function formatText($out, $format)
        {
            $src = array('%n', '%m', '%p', '%i', ',');
            $rep = array($out[2], $out[3], $out[5].'/'.$out[4], $out[1], $this->options['seperator']);

            return str_replace($src, $rep, $format);
        }
	}

    function sortProtos($a, $b)
    {
		return ($a[2] < $b[2]) ? -1 : 1;
    }

?>