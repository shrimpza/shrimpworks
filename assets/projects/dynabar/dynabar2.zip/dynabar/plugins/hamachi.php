<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class hamachi extends UbarPlugin
	{
        var $enabled = true;
        var $cacheTime = 120;
		var $friendlyName = "Hamachi Status";
        var $help = "Display the status of a Hamachi users connection.";

		var $paramMap = array(
				'ip' => array('IP Address', 'str'),
			);

		function fetchText()
		{
            if (!isset($this->options['ip']))
                return "No IP set!";

			$status = @file('http://my.hamachi.cc/status/text.php?'.$this->options['ip']);
			if ($status !== false)
			{
				if (count($status) > 0)
					return substr(trim($status[0]), strpos(trim($status[0]), ' ')+1);
				else
					return "No status?!";
			}
			else
				return false;
		}
	}

?>