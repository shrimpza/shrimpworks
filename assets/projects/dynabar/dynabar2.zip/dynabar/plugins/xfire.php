<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class xfire extends UbarPlugin
	{
        var $enabled = true;
		var $friendlyName = "XFire Profile";
        var $help = "Displays various info from a specified XFire users profile.";

		var $paramMap = array(
				'user' => array('Username', 'str'),
                'stat' => array('Show', array(
                                               -1 => 'Random',
                                                0 => 'Online status',
                                                1 => 'Top game time this week',
                                                2 => 'Top game time overall',
                                            )),
			);

		function fetchText()
		{
            if (!isset($this->options['user']))
                return "No username!";

            $xfire = new cxsProfile($this->options['user']);
            $profile = $xfire->profile;
			if ($profile != 0)
			{
                if ($this->options['stat'] < 0)
                    $this->options['stat'] = rand(0, 2);

                if ($this->options['stat'] == 0)
                    return ($profile['online'] == 1) ? 'Status: Online' : 'Status: Offline';
                else if ($this->options['stat'] == 1)
                    return 'This week: ' . $profile['top_thisweek']['name'] . ' - ' . $profile['top_thisweek']['time'];
                else if ($this->options['stat'] == 2)
                    return 'All time: ' . $profile['top_alltime']['name'] . ' - ' . $profile['top_alltime']['time'];
			}
			else
				return false;
		}

    }

    // a lil class wrapping the functions very kindly provided by the 
    // "CXS - Custom Xfire Sigs" site: http://customsigs.free.fr/
    class cxsProfile
    {
        var $profile;

        function cxsProfile($user)
        {
            $this->profile = $this->xfire_read($user);
            $this->profile['top_thisweek'] = $this->getHours($this->profile, 1);
            $this->profile['top_alltime'] = $this->getHours($this->profile, 2);
        }

        // ------------
        // xfire_info reads all of the xfire user information into an array, and returns it.
        // ------------
        function xfire_read($name) 
        { 
            if ($content = file_get_contents('http://www.xfire.com/profile/'.$name))
            { 
                preg_match_all("/\<tr  colData0=.*?\>.*?\<td class=\"m_est_stats_rows_iconcol\"\>.*?<img src=\"(.*?)\" width=\"16\" height=\"16\" alt=\".*?\" \/\>.*?\<\/td\>.*?<td class=\"m_est_stats_rows_gamecol\"\>(.*?)\<\/td\>.*?\<td class=\"m_est_stats_rows_weekcol\"\>(.*?)\<\/td\>.*?\<td class=\"m_est_stats_rows_totalcol\"\>(.*?)\<\/td\>.*?\<\/tr\>/s", $content, $gamedata);
                unset($gamedata[0]);

                foreach($gamedata[2] as $k => $v)
                    $gamedata[2][$k] = rtrim(ltrim($v));
                foreach($gamedata[3] as $k => $v)
                    $gamedata[3][$k] = rtrim(ltrim($v));
                foreach($gamedata[4] as $k => $v)
                    $gamedata[4][$k] = rtrim(ltrim($v));

                $icons = $gamedata[1];$names = $gamedata[2];$this_week = $gamedata[3];$all_time = $gamedata[4];
                unset($gamedata);
                preg_match ("/\<strong\>User is:\<\/strong\>(.*?)\<span class=\"(.*?)\"\>\<b\>(.*?)\<\/b\>\<\/span\>/s", $content, $online);
                preg_match ("/\<th\>Nickname: \<\/th\>.*?\<td\>.*?\<a href=\"\/profile\/.*?\"\>(.*?)\<\/a\>.*?\<\/td\>/s", $content, $nickname);
                preg_match("/\<div class=\"m_profile_avatar\"\>.*?\<img src='(.*?)' alt='' \/\>.*?\<\/div\>/s",$content,$avatar);

                preg_match("/<th>Location:<\/th>\s+<td>(.*?)<\/td>/i",$content,$location);
                preg_match("/<th>Age:<\/th>\s+<td>(.*?)<\/td>/i",$content,$age);
                preg_match("/<th>Gender:<\/th>\s+<td>(.*?)<\/td>/i",$content,$gender);
                preg_match("/<th>Gaming Style: <\/th>\s+<td>(.*?)<\/td>/i",$content,$gamestyle);
                preg_match("/<th scope=\"row\">Real Name: <\/th>\s+<td>(.*?)<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">IRC Channel: <\/th>\s+<td>(.*?)<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">Web Site: <\/th>\s+<td><a href=\"(.*?)\">(.*?)<\/a>\s+<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">Occupation: <\/th>\s+<td>(.*?)<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">Status: <\/th>\s+<td>(.*?)<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">Hobbies &amp; Interests: <\/th>\s+<td>(.*?)<\/td>\s+<\/tr>\s+<tr>\s+<th scope=\"row\">About Me: <\/th>\s+<td>(.*?)<\/td>/i",$content,$more);
                unset($more[0]);
                $online = $online[2];

                return Array("icons" => $icons,    "names" => $names, "this_week" => $this_week, "all_time" => $all_time, "online" => ($online == 'online') ? 1:0, "nickname" => $nickname[1], "username" => $name, "avatar" => $avatar[1],"location" => $location[1],"age"=>$age[1],"gender"=>$gender[1],"gamestyle"=>$gamestyle[1],"more"=>$more);
            }
            else
                return 0;
        }

        // ------------
        // cleanHours is a function which converts the hours array into usable information
        // ------------
        function cleanHours(&$arr)
        {
            foreach( $arr as $key=>$data)
            {
                $arr[$key] = str_replace('-', '0', $data);
                $arr[$key] = str_replace('< 1 hour', '0.1', $arr[$key]);
                $arr[$key] = str_replace(' hours', '', $arr[$key]);
                $arr[$key] = str_replace(' hour', '', $arr[$key]);
            }
        }

        // ------------
        // sortData sorts the data accordingly, so that it can be easily used. It's actually pretty inefficient, but at least it works.
        // ------------
        function sortData(&$sortarr,$type=1)
        {
            // 1 = Sort to THIS WEEK
            // 2 = Sort to ALL TIME
            // 3 = Sort to GAME NAME
            $this->cleanHours($sortarr['this_week']);
            $this->cleanHours($sortarr['all_time']);

            if ($type == 1)
            {
                arsort($sortarr['this_week']);
                foreach ($sortarr['this_week'] as $key => $val)
                {
                    $temparr['this_week'][$key] = $sortarr['this_week'][$key];
                    $temparr['names'][$key] = $sortarr['names'][$key];
                    $temparr['icons'][$key] = $sortarr['icons'][$key];
                    $temparr['all_time'][$key] = $sortarr['all_time'][$key];
                }
                $temparr['this_week'] = @array_values($temparr['this_week']);
                $temparr['names'] = @array_values($temparr['names']);
                $temparr['icons'] = @array_values($temparr['icons']);
                $temparr['all_time'] = @array_values($temparr['all_time']);
                $sortarr = $temparr;
            }

            if ($type == 2)
            {
                arsort($sortarr['all_time']);
                foreach($sortarr['all_time'] as $key => $val)
                {
                    $temparr['this_week'][$key] = $sortarr['this_week'][$key];
                    $temparr['names'][$key] = $sortarr['names'][$key];
                    $temparr['icons'][$key] = $sortarr['icons'][$key];
                    $temparr['all_time'][$key] = $sortarr['all_time'][$key];
                }
                $temparr['this_week'] = @array_values($temparr['this_week']);
                $temparr['names'] = @array_values($temparr['names']);
                $temparr['icons'] = @array_values($temparr['icons']);
                $temparr['all_time'] = @array_values($temparr['all_time']);
                $sortarr = $temparr;
            }
        }

        // ------------
        // getHours returns the largest amount of hours for both "this week" and "all time"
        // ------------
        function getHours($arr, $type)
        {
            // 1 = THIS WEEK
            // 2 = ALL TIME
            if ($type == 1)
            {
                $this->sortData($arr,1);
                $temp = Array("icon" => $arr["icons"][0], "name" => $arr["names"][0], "time" => $arr["this_week"][0]);
                return $temp;
            }

            if ($type == 2)
            {
                $this->sortData($arr,2);
                $temp = Array("icon" => $arr["icons"][0], "name" => $arr["names"][0], "time" => $arr["all_time"][0]);
                return $temp;
            }
        }

        // ------------
        // formatHour returns the numerical data in the format required for the 
        // ------------
        function formatHour($hour)
        {
            return ($hour == 1) ? $hour .' hr' : ( ($hour == 0.1) ? '<1 hr' : $hour . ' hrs' );
        } 

        // ------------
        // sumHours returns all of the hours added up. The second argument is optional, and is what you want to interpret the "less than an hour" time. 
        // Example: sumHours($xfire_data['all_time']) will return all of it added up, using less than 1 hr as half an hour
        //        sumHours($xfire_data['all_time'],0); will return it added up, not adding the less than 1 hr times.
        // ------------
            
        function sumHours($arr, $lt = 0.5)
        {
            $total='';
            foreach ($arr as $k => $a)
            {
                $a = str_replace(' hrs', '', $a);         // Sort out the numerical values
                $a = str_replace('1 hr', 1, $a);
                $a = str_replace('less than one hr', $lt, $a);    
                $total += $a;                           // Increment
            }
            return $total;
        }

    }

?>