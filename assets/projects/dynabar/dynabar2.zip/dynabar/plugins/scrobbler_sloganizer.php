<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class scrobbler_sloganizer extends UbarPlugin
	{
        var $enabled = true;
		var $friendlyName = "LastFM Artist Sloganizer";
        var $help = "Uses a LastFM profiles top 10 artists in combination with Sloganizer.";

		var $paramMap = array(
				'user' => array('Username', 'str'),
			);

		function fetchText()
		{
            if (!isset($this->options['user']))
                return "No username!";

            $artists = @file('http://ws.audioscrobbler.com/1.0/user/'.$this->options['user'].'/topartists.txt');
			if ($artists !== false)
			{
                $rnd = mt_rand(0, min(10, count($artists)));
				if (count($artists) > 0)
                    $artist = trim(substr($artists[$rnd], strrpos($artists[$rnd], ',')+1));
				else
					return "No artists!";

                $slogan = @file('http://www.sloganizer.net/en/outbound.php?slogan='.$artist);
                if ($slogan !== false)
                {
                    if (count($slogan) > 0)
                        return trim(strip_tags($slogan[0]));
                    else
                        return "No slogan?!";
                }
            }
			else
				return false;
		}
	}

?>