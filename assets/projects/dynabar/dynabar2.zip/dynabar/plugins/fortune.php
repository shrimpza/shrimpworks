<?php
	/*
		DynaBar UserBar

		by Kenneth Watson
		http://shrimpworks.za.net/

		July 2006

		See docs/README and docs/COPYING for more information.
	*/

	class fortune extends UbarPlugin
	{
        var $enabled = true;
        var $execPath = '/usr/games/fortune';   // path to fortune

		var $cacheTime = 30;	// should be ok to spam fortune requests a little
		var $friendlyName = "Fortune [exec]";
        var $help = "Display a fortune from the forutne program. Requires a *nix server with fortune installed.";

		var $paramMap = array(
				'maxlength' => array("Max Length", array(30 => '30', 40 => '40', 50 => '50')),
			);

		function fetchText()
		{
			return trim(str_replace('  ', ' ', str_replace("\t", ' ', str_replace("\n", ' ', shell_exec($this->execPath . ' -sn ' . max(20, $this->options['maxlength']))))));
		}
	}

?>
