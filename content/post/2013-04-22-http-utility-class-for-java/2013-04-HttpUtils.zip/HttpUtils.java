import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author Shrimp
 */
public class HttpUtils {

    private static int readTimeout = 20000;

    /**
     * Perform a HEAD request on a URL. Handy to test an HTTP server's status
     *
     * @param webUrl the URL to check.
     * @return the server's response
     */
    public static String httpHead(String webUrl) throws MalformedURLException, IOException {
        return httpRequest("HEAD", webUrl, null);
    }

    /**
     * Perform a basic GET request.
     *
     * @param webUrl the URL to page/service to request. the URL should contain
     * any HTTP-encoded query parameters required.
     * @return the server's response
     */
    public static String httpGet(String webUrl) throws MalformedURLException, IOException {
        return httpRequest("GET", webUrl, null);
    }

    /**
     * POSTs simple data to a URL
     *
     * @param webUrl the URL of the page/service to submit data to
     * @param postContent HTTP-encoded key/value pairs separated with
     * ampersands; or other data the remote service is expecting.
     * @return the server's response
     */
    public static String httpPost(String webUrl, String postContent) throws MalformedURLException, IOException {
        return httpRequest("POST", webUrl, postContent);
    }

    private static String httpRequest(String httpMethod, String httpUrl, String postContent) throws MalformedURLException, IOException {
        HttpURLConnection conn;

        URL url = new URL(httpUrl);
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(httpMethod);
        conn.setDoOutput(true);
        conn.setReadTimeout(readTimeout);
        conn.connect();

        OutputStreamWriter wr = null;
        BufferedReader rd = null;
        StringBuilder sb = null;

        try {
            if (postContent != null) {
                wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(postContent);
                wr.flush();
            }

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            sb = new StringBuilder();
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
        } finally {
            if (wr != null) {
                wr.close();
            }

            if (rd != null) {
                rd.close();
            }
        }

        return sb.toString();
    }

    /**
     * @return the current read timeout for HTTP requests
     */
    public static int getReadTimeout() {
        return readTimeout;
    }

    /**
     * Set the read timeout for HTTP requests
     *
     * @param readTimeout timeout in milliseconds
     */
    public static void setReadTimeout(int readTimeout) {
        HttpUtils.readTimeout = readTimeout;
    }
}